# foicesemoedas
Projeto Foices e Moedas - 2AINFO
